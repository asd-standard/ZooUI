## ZooUI - Zooming User Interface
## Copyright (C) 2009 David Roberts <d@vidr.cc>
##
## This program is free software; you can redistribute it and/or
## modify it under the terms of the GNU General Public License
## as published by the Free Software Foundation; either version 3
## of the License, or (at your option) any later version.
##
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program; if not, see <https://www.gnu.org/licenses/>.

"""
ZooUI is a Zooming User Interface for Python.
https://asd-standard.github.io/ZooUI/
"""

__author__ = "David Roberts, Andrea Silvestri"
__copyright__ = "Copyright (C) 2009  David Roberts <d@vidr.cc>\n<http://da.vidr.cc/projects/pyzui/>"
__copyright_notice__ = """
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, see <https://www.gnu.org/licenses/>.
"""
__credits__ = ["David Roberts, Andrea Silvestri"]
__license__ = "GPLv3"
__version__ = "0.6.2"
__maintainer__ = "Andrea Silvestri"
__email__ = "asd.standard@gmail.com"

__all__ = [
    "backup",
    "config",
    "converter",
    "dynamictileprovider",
    "ferndynamictileprovider",
    "mainwindow",
    "mediaobject",
    "pdfconverter",
    "physicalobject",
    "ppm",
    "qzui",
    "scene",
    "statictileprovider",
    "stringmediaobject",
    "svgmediaobject",
    "tile",
    "tilecache",
    "tiledmediaobject",
    "tilemanager",
    "tileprovider",
    "tiler",
    "tilestore",
    "vipsconverter",
]
